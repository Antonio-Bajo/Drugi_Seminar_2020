#ifndef _SELECTION_SORT_H_
#define _SELECTION_SORT_H_
#include <vector>
#include "MovieOrShow.h"

int selection_sort(vector<MovieOrShow> &data, int n);

#endif