#ifndef _COUNTING_SORT_H_
#define _COUNTING_SORT_H_

#include <vector>
#include <sstream>
#include <string>
using namespace std;


//Vraca sadrzaj starog polja 
//stringstream jer sadrzi <<endl
void counting_sort(vector<int>& dataV,const int n,stringstream &ss);


#endif
