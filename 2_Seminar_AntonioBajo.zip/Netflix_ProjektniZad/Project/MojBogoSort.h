#pragma once
#include <vector>
#include "MovieOrShow.h"
using namespace std;

	int moj_bogo_sort(vector<MovieOrShow>& v);

