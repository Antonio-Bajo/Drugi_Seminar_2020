#include "MovieOrShow.h"
#include <iostream>
#include <sstream>
#

MovieOrShow::MovieOrShow()
{
}

MovieOrShow::MovieOrShow(string line)
{
	string temp;

	//LINE
	stringstream ss(line);

	//ID
	getline(ss, temp, ',');
	stringstream sstemp(temp);
	sstemp >> id;

	//TYPE
	getline(ss, temp, ',');
	if (temp == "Movie")type = 1;
	else type = 0;

	//TITLE
	getline(ss, temp, ',');
	if (temp.size() > 0 && temp[0] == '"')
	{
		sstemp.clear();
		sstemp << temp;
		if (temp[temp.size() - 1] == '"')
		{
			title = temp;
			goto jump;
		}
		do
		{
			getline(ss, temp, ',');
			sstemp << temp;
		} while (temp[temp.size() - 1] != '"');
		title = sstemp.str();
	}
	else
	{
		title = temp;
	}
jump:



	//DIRECTOR
	getline(ss, temp, ',');
	if (temp.size() > 0 && temp[0] == '"') //ime vise direktora	// npr. "Richard Finn, Tim Maltby", 
	{
		if (temp[temp.size() - 1] == '"')
		{
			director.push_back(temp);
			goto jump2;
		}
		director.push_back(temp);
		do
		{
			getline(ss, temp, ',');
			director.push_back(temp);

		} while (temp[temp.size() - 1] != '"');

		director[0].erase(director[0].begin()); //brise  ' " ' iz provg
		director[director.size() - 1].erase(director[director.size() - 1].end() - 1); //brise " iz zadnjeg
	}
	else
	{
		director.push_back(temp);
	}
jump2:


	//CAST
	getline(ss, temp, ',');
	if (temp.size() > 0 && temp[0] == '"') //ime vise castova	// npr. "Richard Finn, Tim Maltby", 
	{

		if (temp[temp.size() - 1] == '"')
		{
			cast.push_back(temp);
			goto jump3;
		}
		cast.push_back(temp);
		do
		{

			getline(ss, temp, ',');
			cast.push_back(temp);

		} while (temp[temp.size() - 1] != '"');
		cast[0].erase(cast[0].begin()); //brise  ' " ' iz provg
		cast[cast.size() - 1].erase(cast[cast.size() - 1].end() - 1); //brise " iz zadnjeg

	}
	else
	{
		cast.push_back(temp);
	}
jump3:

	//COUNTRY
	getline(ss, temp, ',');
	if (temp.size() > 0 && temp[0] == '"') //ime vise castova	// npr. "Richard Finn, Tim Maltby", 
	{
		if (temp[temp.size() - 1] == '"')
		{
			country.push_back(temp);
			goto jump4;
		}
		country.push_back(temp);
		do
		{
			getline(ss, temp, ',');
			country.push_back(temp);


		} while (temp[temp.size() - 1] != '"');
		country[0].erase(country[0].begin()); //brise  ' " ' iz provg
		country[country.size() - 1].erase(country[country.size() - 1].end() - 1); //brise " iz zadnjeg

	}
	else
	{
		country.push_back(temp);
	}
jump4:


	//DATE_ADDED       
	getline(ss, temp, ',');
	if (temp.empty())
	{
		date_added = "";
	}
	else
	{
		sstemp.clear();
		sstemp << temp;
		getline(ss, temp, ',');
		sstemp << temp;

		date_added = sstemp.str();
		
		if (date_added[date_added.size() - 1] == '"')date_added.pop_back();

		for (auto& c : date_added)
		{
			if (c == '"')
			{
				c = ' ';
			}
		}
	}



	//RELEASE_YEAR
	getline(ss, temp, ',');
	sstemp.clear();
	sstemp.str(temp);
	sstemp >> release_year;


	//RATING
	getline(ss, rating, ',');

	//DURATION
	getline(ss, duration, ',');

	//LISTEN_IN
	getline(ss, temp, ',');
	if (temp.size() > 0 && temp[0] == '"') //ime vise castova	// npr. "Richard Finn, Tim Maltby", 
	{
		if (temp[temp.size() - 1] == '"')
		{
			listen_in.push_back(temp);
			goto jump5;
		}
		listen_in.push_back(temp);
		do
		{
			getline(ss, temp, ',');
			listen_in.push_back(temp);

		
			
		} while (temp[temp.size() - 1] != '"');
		listen_in[0].erase(listen_in[0].begin()); //brise  ' " ' iz provg
		listen_in[listen_in.size() - 1].erase(listen_in[listen_in.size() - 1].end() - 1); //brise " iz zadnjeg

	}
	else
	{
		listen_in.push_back(temp);
	}
	jump5:

	//DESCRIPTION
	getline(ss, description);

}
	

	
	


 int MovieOrShow::get_id()const
{
	return id;
}

bool MovieOrShow::get_type()const
{
	return type;
}

string MovieOrShow::get_title() const
{
	return title;
}

vector<string> MovieOrShow::get_director()const
{
	return director;
}

vector<string> MovieOrShow::get_cast()const
{
	return cast;
}

vector<string> MovieOrShow::get_country()const
{
	return country;
}

string MovieOrShow::get_date_added()const
{
	return date_added;
}

int MovieOrShow::get_release_year()const
{
	return release_year;
}

string MovieOrShow::get_rating()const
{
	return rating;
}

string MovieOrShow::get_duration()const
{
	return duration;
}

vector<string> MovieOrShow::get_listen_in()const
{
	return listen_in;
}

string MovieOrShow::get_descritpion()const
{
	return description;
}

void MovieOrShow::set_id(unsigned int id)
{
	this->id = id;
}

void MovieOrShow::set_type(bool type)
{
	this->type = type;
}

void MovieOrShow::set_title(string title)
{
	this->title = title;
}

void MovieOrShow::set_director(vector<string> director)
{
	this->director = director;
}

void MovieOrShow::set_cast(vector<string> cast)
{
	this->cast = cast;
}

void MovieOrShow::set_country(vector<string> country)
{
	this->country = country;
}

void MovieOrShow::set_date_added(string date_added)
{
	this->date_added = date_added;
}

void MovieOrShow::set_release_year(int release_year)
{
	this->release_year = release_year;
}

void MovieOrShow::set_rating(string rating)
{
	this->rating = rating;
}

void MovieOrShow::set_duration(string duration)
{
	this->duration = duration;
}

void MovieOrShow::set_listen_in(vector<string> listen_in)
{
	this->listen_in = listen_in;
}

void MovieOrShow::set_description(string description)
{
	this->description = description;
}

string MovieOrShow::to_string()const
{

	stringstream directors;
	for (unsigned i = 0; i < director.size(); i++)
	{
		
		directors << director[i] << " ";
	}
	stringstream listen_ins;
	for (unsigned i = 0; i < listen_in.size(); i++)
	{
		listen_ins << listen_in[i] << " ";
	}
	stringstream casts;
	for (unsigned i = 0; i < cast.size(); i++)
	{
		casts << cast[i] << " ";
	}	
	stringstream countrys;
	for (unsigned i = 0; i < country.size(); i++)
	{
		countrys << country[i] << " ";
	}

	string type_string;
	if (type)
	{
		type_string = "movie";
	}
	else
	{
		type_string = "TV show";
	}

	stringstream ss;
	ss <<
		" ID: " << id << endl
		<< "type: " << type_string << endl
		<< "title: " << title << endl
		<< "directors: " << directors.str() << endl
		<< " casts: " << casts.str() << endl
		<< " countrys: " << countrys.str() << endl
		<< "date_added: " << date_added << endl
		<< " release_year: " << release_year << endl
		<< " rating: " << rating << endl
		<< " duration: " << duration << endl
		<< " listen_ins: " << listen_ins.str() << endl
		<< " desc: " << description << endl;

	return ss.str();
}



