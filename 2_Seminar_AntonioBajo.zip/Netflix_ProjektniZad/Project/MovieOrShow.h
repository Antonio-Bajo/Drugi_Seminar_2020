#pragma once
#include <fstream>
#include <string>
#include <vector>
using namespace std;

class MovieOrShow
{
public:
	MovieOrShow();
	MovieOrShow(string line);

	//*****GETERI****
	 int get_id()const;
	bool get_type()const;	//1-movie  ,  0-TV show
	string get_title() const;
	vector<string> get_director()const;
	vector<string> get_cast()const;
	vector<string> get_country()const;
	string get_date_added()const;
	int get_release_year()const;
	string get_rating()const;
	string get_duration()const;
	vector<string> get_listen_in()const;
	string get_descritpion()const;

	//***SETERI***  //
	void set_id(unsigned int id);
	void set_type(bool type);
	void set_title(string title);
	void set_director(vector<string> director);
	void set_cast(vector<string> cast);
	void set_country(vector<string> country);
	void set_date_added(string date_added);
	void set_release_year(int release_year);
	void set_rating(string rating);
	void set_duration(string duration);
	void set_listen_in(vector<string> listen_in);
	void set_description(string description);

	//ISPIS
	string to_string() const;

private:
	 int id;
	bool type;
	string title;
	//moze biti vise direktora/castoa/drzava
	vector<string> director;
	vector<string> cast;
	vector<string> country;
	string date_added;
	int release_year;
	string rating;
	string duration;
	vector<string> listen_in;
	string description;
};

//Komparatori
struct rastuce
{
	bool operator()(MovieOrShow a, MovieOrShow b)
	{
		return a.get_release_year() > b.get_release_year();
	}
};

struct padajuce
{
	bool operator()(MovieOrShow a, MovieOrShow b)
	{
		return a.get_release_year() < b.get_release_year();
	}
};


struct padajuce_prema_broju_drzava
{
	bool operator()(MovieOrShow a, MovieOrShow b)
	{
		return a.get_country().size() < b.get_country().size();
	}
};