#include <iostream>
#include <algorithm>
#include <vector>
#include <fstream>
#include "MovieOrShow.h"
#include <string>
#include <sstream>
#include <list>
#include <map>
#include <chrono>
#include <algorithm>
#include <queue>
#include <ctime>
#include "selection_sort.h"
#include "shell_sort.h"
#include "MojBogoSort.h"
#include "counting_sort.h"
#include <unordered_map>
#include <unordered_set>

using namespace std;
using namespace std::chrono;

void to_upper(string& tekst)
{
	for (auto& c : tekst)
	{
		c = toupper(c);
	}
}

string to_upper_return(string tekst)
{
	for (auto& c : tekst)
	{
		c = toupper(c);
	}
	return tekst;
}

void load(ifstream& in, vector<MovieOrShow>& netflix, const int N)
{
	//ne znam zasto ali mi program ne prepoznaje \r, 
	//getline(in,line,'r)
	//cout <<line;			--Ipise cijeli file
	//system("pause")
	// pa sam gledao po drugom kriteriju
	
	cout << "...LOADING...";
	string line;
	string temp;

	getline(in, line);
	while (getline(in, line))
	{
		
		//ako je film nije zapisan do kraja u line-i
		if (*line.rbegin() != '.' && *line.rbegin() != '"')
		{
			getline(in, temp);
			stringstream ss (line + temp);
		
			netflix.emplace_back(ss.str());
		}

		else
		{
			netflix.emplace_back(line);
		}
	
	}
}


int gen_rnd(int min, int max)
{
	return rand() % (max - min + 1) + min;
}

//Za input od korisnika koristim stringove da se program nebi zbugiro prilikom krivog unosa 
int to_int(string input)
{
	stringstream temp(input);
	int broj;
	temp >> broj;
	return broj;
}

//za monkey play //stavlja 3 randoma felementa iz v2 u v1
void prepare(vector<MovieOrShow> &v1, vector<MovieOrShow>& v2)
{
	int random;

	for (int i = 0; i < 3; i++)
	{
		random =gen_rnd(0, v2.size() - 1);
		v1.push_back(v2[random]);
	}
}

int main() 
{
	vector<int> mainv{1,2,3,4,5,6,7,8,9,10,11};
	string input;
	string option;
	int option2;
	//Load netflixa 
	vector<MovieOrShow> netflix;
	const int N = 6235; //broj redaka  -1 //zbog prvog retka
	ofstream out("sadrzaj_pomocnog_polja.txt");
	ifstream in("SPA_PROJ_004_NETFLIX_data.csv");
	if (!in ||!out)
	{
		cout << "Error 404";
		return 1;
	}

	load(in, netflix,N);

	do
	{
		//Menu selection
		system("cls");
		cout << " 1) Pretraga po godini izdanja" << endl
			<< " 2) Prikaz po godini izdanja" << endl
			<< " 3) Kopiranje u novu listu" << endl
			<< " 4) Prikaz po vrsti" << endl
			<< " 5) Selection vs Shell" << endl
			<< " 6) Lets play guess" << endl
			<< " 7) Monkey Play" << endl
			<< " 8) Counting" << endl
			<< " 9) Pretraga po imenu" << endl
			<< " 10) Vizualiziraj" << endl
			<< " 11) zrada imena iz imena" << endl << endl
			<< "Odaberi (1-11) : ";
		getline(cin,option);

		cout << option << endl;
		jump:
		
		//------------------------------------------------------------------------------------------------
		//-----------------------1) PRETRAGA PO GODINI IZDANJA------------------------------------------
		if (option == "1")
		{
			//vektor gdje cemo drzati filmove sa zadanom godinom
			vector<int> valid_range;
			stringstream temp;
			vector<MovieOrShow> v;
			vector<pair<int, string>> vrijeme_trazenja(3);
			int godina_izdanja;
			int nacin_ispisa = 1;
			system("cls");


			//---INPUT GODINA IZDANJA---
			cout << "Upisite godinu izdanja: ";
			getline(cin, input);
			godina_izdanja = to_int(input);


			//---INPUT NACIN ISPISA--
			cout << "Odaberite nacin ispisa filmova/serija (1- samo title, 2- svi podaci) :  ";
			getline(cin, input);
			
			nacin_ispisa = to_int(input);

			system("cls");

			//Kopiranje netflixa u listu i mapu
			//Zbog perfomansi trazenja te jer u ovom primjeru uvijem trazimo po godini filma , key od multimape je "released_year"
			//-----KOPIRANJE U LIST I MULTIMAPU-----
			list<MovieOrShow> netflixLista(netflix.begin(), netflix.end());
			multimap<int, MovieOrShow> netflixMapa;
			for(int i=0;i<netflix.size();i++)
			{
				netflixMapa.emplace(netflix[i].get_release_year(), netflix[i]);
			}


			//----TRAZENJE U VEKTORU----
			auto begin = high_resolution_clock::now();
			for (int i = 0; i < netflix.size(); i++)
			{
				if (netflix[i].get_release_year() == godina_izdanja)
				{
					v.push_back(netflix[i]);
				}
			}
			auto end = high_resolution_clock::now();

			vrijeme_trazenja[0].first = duration_cast<microseconds>(end - begin).count();
			vrijeme_trazenja[0].second = "Vektor";

			//-------TRAZENJE U LISTI----
			v.clear();

			begin = high_resolution_clock::now();
			for (auto it = netflixLista.begin(); it != netflixLista.end(); ++it)
			{
				if (it->get_release_year() == godina_izdanja)
				{
					v.push_back(*it);
				}
			}
			 end = high_resolution_clock::now();
			 vrijeme_trazenja[1].first = duration_cast<microseconds>(end - begin).count();
			 vrijeme_trazenja[1].second = "Lista";
			//----TRAZENJE U MAPI-----
			 v.clear();

			 begin = high_resolution_clock::now();
			auto equIt =netflixMapa.equal_range(godina_izdanja);
			
		
			if (equIt.first != equIt.second)
			{
				for (auto it = equIt.first; it != equIt.second; ++it)
				{
					v.push_back(it->second);
				}
			}
			end = high_resolution_clock::now();
			vrijeme_trazenja[2].first = duration_cast<microseconds>(end - begin).count();
			vrijeme_trazenja[2].second = "MultiMapa";



			//---ISPIS FILMOVA ---
			cout << endl <<"Popis Filmova/serija izdani "<<godina_izdanja <<"-te godine :" << endl << endl;
			//ispis svih podaci
			if (nacin_ispisa==2)
			{
				if (v.empty())
				{
					cout << " Nema trazenih filmova/serija! " << endl;
				}
				else
				{
					for (auto& i : v)
					{
						cout << i.to_string() << endl << endl;
					}

				}
			}
			//ispis samo title
			else
			{
				if (v.empty())
				{
					cout << " Nema trazenih filmova/serija !" << endl;
				}
				else
				{
					for (auto& i : v)
					{
						cout <<" - " <<i.get_title() << endl;
					}

				}
			}

			//----ISPIS VRIJEME TRAZENJA---
			sort(vrijeme_trazenja.begin(), vrijeme_trazenja.end());
			cout << endl << "Brzina trazenja: " << endl;
			cout << " - Najbrzi:    " << vrijeme_trazenja[0].second <<" - "<< vrijeme_trazenja[0].first << " microsecond." << endl;
			cout << " - Srednji:    " << vrijeme_trazenja[1].second << " - "<<vrijeme_trazenja[1].first << " microsecond." << endl;
			cout << " - Najsporiji: " << vrijeme_trazenja[2].second << " - " << vrijeme_trazenja[2].first << " microsecond." << endl;
			cout << endl;

			//---INPUT---
			cout << "Odaberi: (1-Ponovni upis , 2-Povratak na glavni meni): ";
			getline(cin, input);
			

			option2 = to_int(input);
			if (option2 == 1)goto jump;
		}

		//------------------------------------------------------------------------------------------------
		//-------------------------- 2) PRIKAZ PO GODINI IZDANJA -----------------------------------------
		else if (option=="2")
		{
			system("cls");

			vector<int> valid_range{ 1,2 };
			int filmIliSerija = 1; // 1-serija , 2-film
			int nacin_ispisa = 1; //1-rastuce, 2-padajuce

			//----INPUT---
			cout << "Odaberite (1-Ispis filmova, 2- ispis serija) ";
			getline(cin, input);
			
			filmIliSerija = to_int(input);

			//---INPUT---
			cout << "Nacinispisa (1-rastuce po godini, 2-Padajuce po godini) :";
			getline(cin, input);
			;
			nacin_ispisa = to_int(input);

			cout << "Popis : " << endl;
			//PRIORITY QUEUE

			//rastuce
			if (nacin_ispisa == 1)
			{
				priority_queue<MovieOrShow, vector<MovieOrShow>, rastuce> netflixQueue(netflix.begin(), netflix.end());
				while (!netflixQueue.empty())
				{
					//filmovi
					if (filmIliSerija != 2)
					{
						if (netflixQueue.top().get_type())
						{
							cout << " - " << netflixQueue.top().get_title() << "("<< netflixQueue.top().get_release_year() <<")"<< endl;
						}
							netflixQueue.pop();
					}
					//serije
					else
					{
						if (!netflixQueue.top().get_type())
						{
							cout << " - " << netflixQueue.top().get_title() << "(" << netflixQueue.top().get_release_year() << ")" << endl;
						}
							netflixQueue.pop();
					}

				}
			}
			//padajuce
			else
			{
				priority_queue<MovieOrShow, vector<MovieOrShow>, padajuce> netflixQueue(netflix.begin(), netflix.end());
				while (!netflixQueue.empty())
				{
					//filmovi
					if (filmIliSerija !=2)
					{
						if (netflixQueue.top().get_type())
						{
							cout << " - " << netflixQueue.top().get_title() << "(" << netflixQueue.top().get_release_year() << ")" << endl;
						}
						netflixQueue.pop();
					}
					//serije
					else
					{
						if (!netflixQueue.top().get_type())
						{
							cout << " - " << netflixQueue.top().get_title() << "(" << netflixQueue.top().get_release_year() << ")" << endl;
						}
						netflixQueue.pop();
					}

				}
			}

			//---INPUT---
			cout << "Odaberi: (1-Ponovni upis , 2-Povratak na glavni meni): ";
			getline(cin, input);
			

			option2 = to_int(input);
			if (option2 == 1)goto jump;

		}



		//------------------------------------------------------------------------------------------------
		//-------------------------- 3) KOPIRANJE U NOVU LIST --------------------------------------------
		else if (option == "3")
		{
			int id;
			system("cls");
			int dalje;
			list<MovieOrShow> netflixLista;

			//--MAP DECLARATION--
			map<int, MovieOrShow> netflixMap;
			for (int i = 0; i < netflix.size(); i++)
			{
				netflixMap[netflix[i].get_id()] = netflix[i];
			}


			//INPUT & STVARANJE MAPE
			do
			{
				cout << "Upisite ID  : ";
				getline(cin, input);
				
				id = to_int(input);

				//ako postoji id -> push u listu
				if (netflixMap.find(id) != netflixMap.end())
				{
					netflixLista.push_back(netflixMap[id]);
				}
				

				again1:
				cout << "Zelite li nastaviti upisivati (1-da,2-ne)";
				getline(cin, input);
				
				dalje = to_int(input);
			} while (dalje!=2);

			//---INPUT NACIN ISPISA--
			cout << "Odaberite nacin ispisa filmova (1- samo title, 2- svi podaci) :  ";
			getline(cin, input);
			
			int nacin_ispisa = to_int(input);


			cout << " Popis : " << endl;
			if (netflixLista.empty()) {
				cout << "* nema trazenih filmova/serija*" << endl << endl;
			}
			else
			{

				//--ISPIS FILMOVA IZ LISTE
				for (auto it = netflixLista.begin(); it != netflixLista.end(); ++it)
				{	
					//ispis svih podatka
					if (nacin_ispisa == 2)
					{
						cout << it->to_string() << endl << endl;
					}
					//ispis samo title
					else
					{
						cout << " - " << it->get_title() << endl;
					}
			}

			}

			//---INPUT---
			cout << "Odaberi (1-Ponovni upis , 2-Povratak na glavni meni): ";
			getline(cin, input);
			
			option2 = to_int(input);

			if (option2 == 1)goto jump;

		}



		//-------------------------------------------------------------------------------------
		//---------------------------PRIKAZ PO VRSTI-------------------------------------------
		else if (option == "4")
		{
			system("cls");


			cout << endl << "Filmovi i serije se sortiraju, molim pricekati";
			priority_queue<MovieOrShow, vector<MovieOrShow>, padajuce_prema_broju_drzava> netflixQueue(netflix.begin(), netflix.end());

			
			vector <MovieOrShow> v;
			//ISPIS FILMOVA
			while (!netflixQueue.empty())
			{
				//ako je film
				if (netflixQueue.top().get_type())
				{
					cout << "(Movie) - ";
					cout << netflixQueue.top().get_title() << ",  Broj drzava: " << netflixQueue.top().get_country().size() << endl;
				}
				else
				{
					v.push_back(netflixQueue.top());
				}

				netflixQueue.pop();
			}

			//ISPIS SERIJA
			for (auto& i : v)
			{
				cout << "(Show) - ";
				cout << i.get_title() << ",  Broj drzava: " << i.get_country().size() << endl;
			}

			//INPUT
			cout << endl<<"Odaberi (1-Ponovni upis , 2-Povratak na glavni meni): ";
			getline(cin, input);
			option2 = to_int(input);

			if (option2 == 1)goto jump;

		}



		//--------------------------------------------------------------------------------------
		//-----------------------------SELECTION VS SHELL---------------------------------------
		else if (option == "5")
		{
			system("cls");
			int nacin_ispisa = 1;
			vector <int> valid_range{ 1,2 };
			int broj_swapova_shell, broj_swapova_selection;

			
			//vectors
			vector<MovieOrShow> v1(netflix.begin(), netflix.end());
			vector<MovieOrShow> v2(netflix.begin(), netflix.end());

			//sort v1
			auto beginv1 = high_resolution_clock::now();
			broj_swapova_selection = selection_sort(v1, v1.size());
			auto endv1 = high_resolution_clock::now();
			//sort v2
			system("cls");
			cout << "Filmovi se sortiraju..(moglo bi potrajati duze vrijeme)" << endl;
			cout << "vector1 je sortiran.(selection_sort)." << endl;
			cout << "vector2 se sortira (shell_sort), molim pricekati";

			auto beginv2 = high_resolution_clock::now();
			broj_swapova_shell = shell_sort(v2, v2.size());
			auto endv2 = high_resolution_clock::now();

			//ISPIS Sortova
			system("cls");
			cout <<endl<< "Vrijeme sortiranja selection sorta: " 
				<< duration_cast<milliseconds>(endv1 - beginv1).count() << " ms"
				<< ",  broj swapova: " << broj_swapova_selection << endl << endl;


			cout << "Vrijeme sortiranja shell sorta: "
				<< duration_cast<milliseconds>(endv2 - beginv2).count() <<" ms"
				<< ",  broj swapova: " << broj_swapova_shell << endl << endl;

			cout << "Kako zelite ispisati filmove/serije? (1-samo title , 2- sve podatke)";
			getline(cin, input);
			nacin_ispisa = to_int(input);

			cout << endl << "Popis filmova/serija : ";
			if (nacin_ispisa != 2)
			{
				for (auto& i : v1)
				{
					cout << " - " << i.get_title() << endl;
				}
			}
			else
			{
				for (auto& i : v1)
				{
					cout << i.to_string() << endl << endl;
				}
			}


			//---INPUT---
			cout << "Odaberi (1-Ponovi sortiranje sortiraj , 2-Povratak na glavni meni): ";
			getline(cin, input);
			

			option2 = to_int(input);
			if (option2 == 1)goto jump;
		}


		//-----------------------------------------------------------------------
		//----------------------LETS PLAY GUESS----------------------------------
		else if (option == "6")
		{
			system("cls");
			vector<int> valid_range{ 1,2 };
			bool found = false;
			srand(time(nullptr));
			int player_guess;
			//gen random
			int n = gen_rnd(1, 100000000);
		

			//INPUT
			cout << "upisite koliko mikrosekundi mislte da ce trajati razbacivanje, sortiranje i binarno pretrazivanje vektora u potrazi za brojem 13 :";
			getline(cin, input);
			player_guess = to_int(input);

			//vector
			vector<int> v;
			for (int i = 1; i <= n; i++)
			{
				v.push_back(i);
			}

			auto begin = high_resolution_clock::now();
			//shuffle
			random_shuffle(v.begin(), v.end());
			//sort
			sort(v.begin(), v.end());
			//search
			found =binary_search(v.begin(), v.end(), 13);
			auto end = high_resolution_clock::now();
			int time= duration_cast<microseconds>(end - begin).count();

			if (found)
			{
				cout << endl << "Vrijeme trajanja : " << time << " mikrosekundi." << endl << endl;
				cout << "Razlika pogodjenog vremena i pravog vremena: " << abs(player_guess - time) << " mikrosekundi." << endl<<endl;

			}
			else
			{
				cout << endl << "Nazalost, vektor nije sadrzavao broj 13" << endl;
			}


			cout << "Odaberi (1-Ponovni upis , 2-Povratak na glavni meni): ";
			getline(cin, input);

			option2 = to_int(input);
			if (option2 == 1)goto jump;

		}



		//--------------------------------------------------------------------------------------
		//-----------------------------MONKEY PLAY---------------------------------------------
		else if (option == "7")
		{
			system("cls");
			vector<MovieOrShow> v;
			prepare(v, netflix);
				

			int broj_pokusaja = moj_bogo_sort(v);

			cout << " Broj_pokusaja da se filmovi sortiraju : " << broj_pokusaja << endl << endl;


			cout << "Odaberi (1-Ponovni, 2-Povratak na glavni meni): ";
			getline(cin, input);

			option2 = to_int(input);
			if (option2 == 1)goto jump;
		}



		//-------------------------------------------------------------------------------------------------
		//------------------------------------8)COUNTING---------------------------------------------------
		else if (option == "8")
		{
			stringstream ss;


			int n;
			system("cls");
			cout << "Upisite maksimalni element n :";
			getline(cin, input);
			n = to_int(input);
			
			cout << "Vektor se kreaira, pricekajte" << endl;
			//vektor
			vector<int> v;
			for (int i = 0; i < 1000; i++)
			{
				v.push_back(gen_rnd(1, n));
			}
			system("cls");
			cout << "Vektor se sortira,pricekajte" << endl;
			//sort
			counting_sort(v, v.size(),ss);
			
			//zapis u dat
			out << ss.str();

			system("cls");
			cout << "Vektor se sortirao!";
			cout << "datoteku elemetni pomocnog polja je zapisan u 'sadrzaj_pomocnog_polja.txt' file-u" << endl << endl;

			//input
			cout << "Odaberi (1-Ponovni upis , 2-Povratak na glavni meni): ";
			getline(cin, input);

			option2 = to_int(input);
			if (option2 == 1)goto jump;
		}





		//-----------------------------------------------------------------------------------------------------
		//----------------------------9) PRETRAGA PO IMENU ----------------------------------------------------
		else if (option == "9")
		{
		 system("cls");
			MovieOrShow movie;
			cout << "Upisite ime filma ili serije (case insesitive): ";
			getline(cin, input);
			to_upper(input);
	
			vector<pair<int, string>> vrijeme_trazenja(3);
			//vektor
			vector<MovieOrShow> v(netflix.begin(), netflix.end());
			//list
			list <MovieOrShow> l(netflix.begin(), netflix.end());
			//unordered map
			//key je title jer se  u ovom primjeru uvijek trazi po title-u 
			unordered_map <string, MovieOrShow> umap;
			for (int i = 0; i < netflix.size(); i++)
			{
				umap[to_upper_return(netflix[i].get_title())] = netflix[i];
			}

			//pretraga u vektoru
			auto begin = high_resolution_clock::now();
			for(auto it=v.begin();it!=v.end();++it){
				if (to_upper_return( it->get_title() ) == input)
				{
					auto VektorIT = it;
					break;
				}
			}
			auto end = high_resolution_clock::now();
			vrijeme_trazenja[0].first = duration_cast<microseconds>(end - begin).count();
			vrijeme_trazenja[0].second = "Vektor";



			//pretraga u listi
			 begin = high_resolution_clock::now();
			for (auto it = l.begin(); it != l.end(); ++it)
			{
				if (to_upper_return(it->get_title()) == input)
				{
					auto listIT=it;
					break;
				}
			}
			 end = high_resolution_clock::now();
			vrijeme_trazenja[1].first = duration_cast<microseconds>(end - begin).count();
			vrijeme_trazenja[1].second = "Lista";


			
			//pretraga u unordered map
			 begin = high_resolution_clock::now();

			auto umapIT= umap.find(input);

			 end = high_resolution_clock::now();


			if (umapIT !=umap.end())
			{
				movie = umapIT->second;
				cout<<endl << "Trazeni title je nadjen." << endl;
				cout << endl << "Brzina trazenja: " << endl;
			}
			else
			{
				cout <<endl<< "Trazeni title NIJE nadjen!" << endl;
				cout << endl << "Brzina prolaska kroz kontejnere : " << endl;
			}
			 
			 vrijeme_trazenja[2].first = duration_cast<microseconds>(end - begin).count();
			 vrijeme_trazenja[2].second = "Unordered Map";

			 //----ISPIS VRIJEME TRAZENJA---
			 sort(vrijeme_trazenja.begin(), vrijeme_trazenja.end());
			 cout << " - Najbrzi:    " << vrijeme_trazenja[0].second << " - " << vrijeme_trazenja[0].first << " microsecond." << endl;
			 cout << " - Srednji:    " << vrijeme_trazenja[1].second << " - " << vrijeme_trazenja[1].first << " microsecond." << endl;
			 cout << " - Najsporiji: " << vrijeme_trazenja[2].second << " - " << vrijeme_trazenja[2].first << " microsecond." << endl;
			 cout << endl;

			 //---INPUT---
			 cout << "Odaberi: (1-Ponovni upis , 2-Povratak na glavni meni): ";
			 getline(cin, input);
			 

			 option2 = to_int(input);
			 if (option2 == 1)goto jump;

		}




		//-----------------------------------------------------------------------------------------
		//------------------------------------10)viziualizira-----------------------------------------

		else if (option == "10")
		{
			system("cls");
			bool temp = false;
			//declaration
			unordered_map<int, MovieOrShow> Umap;
			for (int i = 0; i < netflix.size(); i++)
			{
				Umap[netflix[i].get_id()] = netflix[i];
			}

			for (int i = 0; i < Umap.bucket_count(); i++) {
				cout << "Bucket " << i << ": ";

				if (!Umap.bucket_size(i))
				{
					cout << " [EMPTY]";
				}
				else
				{
					for (auto it = Umap.begin(i); it != Umap.end(i); ++it) 
					{
						if (temp)cout << " --";
						cout <<" " <<it->second.get_title();
						temp = true;
					}
				}
					temp = false;
					cout << endl;
			}



			cout << "Odaberi: (1-Ponovni ispis , 2-Povratak na glavni meni): ";
			getline(cin, input);


			option2 = to_int(input);
			if (option2 == 1)goto jump;
		}






		//-----------------------------------------------------------------------
		//-----------------------izreda imena iz imena-----------------------
		else if (option == "11")
		{	
			string odabir;
			system("cls");
			bool krivi_unos = false;
			string temp;	
			unordered_set<string> us ;
			for (int i = 0; i < netflix.size(); i++)
			{
				temp = netflix[i].get_title();
				to_upper(temp);
				us.emplace(temp);
			}
			//npr char a se ponavlja 2 puta
			unordered_map<char, int> um1;
			unordered_map<char, int> um2;

			//INPUT
			cout << "Odaberite: " << endl
				<< "\t1) (Zelim raditi samo s filmovima iz baze netflix) " << endl
				<< "\t2) (Zelim raditi s bilo kakvim stringovima)"<<endl
				<< "Moj odabir (1/2) : ";
			getline(cin, odabir);


			//INPUT (Title - prvi film)
			if (odabir == "1")
			{
				//input 1  (u petlji dok film nije pronadjen)
				do
				{
					system("cls");
					if (krivi_unos)cout << "Film nije pronadjen!" << endl;

					cout << "Upisite ime prvog filma ili serija: ";
					getline(cin, input);
					to_upper(input);


					if (us.find(input) == us.end())
					{
						krivi_unos = true;
					}
					else
					{
						krivi_unos = false;
					}

				} while (krivi_unos);
			}
			else
			{
				cout << "Upisite ime prvog filma ili serija: ";
				getline(cin, input);
				to_upper(input);
			}
			

			//unorered_map1;
			for (auto& c : input)
			{

				auto um1IT = um1.find(c);

				//ako je pronadjen -> dodaj +1
				if (um1IT != um1.end())
				{
					int temp = um1IT->second;
					um1IT->second = ++temp;
				}
				else
				{
					um1[c] = 1;
				}
			}

			cout << endl;
			krivi_unos = false;

			//INPUT2
			if (odabir == "1")
			{
				//input 2  (u petlji dok film nije pronadjen)
				do
				{
					system("cls");
					if (krivi_unos)cout << "Film nije pronadjen!" << endl;
					cout << "Upisite ime drugog filma ili serija: ";

					getline(cin, input);
					to_upper(input);
					if (us.find(input) == us.end()) krivi_unos = true;
					else
					{
						krivi_unos = false;
					}

				} while (krivi_unos);

			}
			else
			{
				cout << "Upisite ime drugog filma ili serija: ";
				getline(cin, input);
				to_upper(input);
			}


			//unorered map 2
			for (auto& c : input)
			{
				auto um2IT = um2.find(c);
				//ako je pronadjen - dodaj +1
				if (um2IT != um2.end())
				{
					int temp = um2IT->second;
					um2IT->second = ++temp;
				}
				else
				{
					um2[c] = 1;
				}
			}
			

			

				bool izrada_iz_imena = true;


					//gleda svaki bucket iz um2 , ako je u bucketu char, loopaj (again) sve dok vrijednost u kljucu chara nije nula
					for (auto it = um2.begin(); it != um2.end(); ++it) {

						again:
						//nadji bucket 
						auto it2 = um1.find(it->first);   //it2->second = 2		//it->first = A
						
						//ako nema tog bucketa ili u bucketu nema raspolozivili broj charova -> break
						if (it2 == um1.end() || it2->second == 0)
						{

							izrada_iz_imena = false;
							break;
						}

						//umanji broj tih charova za 1
						it2->second--;
						it->second--;
						//ako ima jos charova iz druge mape , ponovi sve dok ne dodje na nulu
						if (it->second > 0)goto again;
					}
				


				if (izrada_iz_imena) {
					cout << "Ime drugog filma se moze kreirati koristeci slova prvoga." << endl;
				}

				else
				{
					cout << "Ime drugog filma se NE moze kreirati koristeci slova prvoga." << endl;
				}


				cout << "Odaberi: (1-Ponovni uspis , 2-Povratak na glavni meni): ";
				getline(cin, input);


				option2 = to_int(input);
				if (option2 == 1)goto jump;
		
		}
		



	} while (true);





	in.close();
	out.close();
	return 0;
}