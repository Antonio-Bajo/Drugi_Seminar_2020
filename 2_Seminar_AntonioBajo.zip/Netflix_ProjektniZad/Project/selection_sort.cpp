#include <iostream>
#include "selection_sort.h"
#include "MovieOrShow.h"
#include <iostream>
using namespace std;

void draw(int &n)
{
	system("cls");
	cout << "Filmovi se sortiraju..(moglo bi potrajati duze vrijeme)" << endl;
	cout << "vector1 se sortira(selection_sort), molim pricekati   [";
	cout << n;
	cout << " /12]" << endl;
	n++;
}

int selection_sort(vector<MovieOrShow>& data, int n) {
	int t = 0;
	int broj_swapova = 0;
	for (int i = 0; i < n - 1; i++) {

		if (i % 500 == 0)draw(t);
		int min_index = i;
		for (int j = i + 1; j < n; j++) {
			if (data[j].get_title() > data[min_index].get_title()) {
				min_index = j;
			}
		}

		swap(data[min_index], data[i]);
		broj_swapova++;
	}
	return broj_swapova;
}