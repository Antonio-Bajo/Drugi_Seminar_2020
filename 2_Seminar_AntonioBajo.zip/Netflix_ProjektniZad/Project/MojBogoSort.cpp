#include "MojBogoSort.h"
#include <algorithm>
#include <iostream>

int moj_bogo_sort(vector<MovieOrShow>& v)
{
	bool sorted = true;
	int n = 0;
	do
	{
		n++;
		sorted = true;
		random_shuffle(v.begin(), v.end());

		//provjera
		for (int i = 1; i < v.size(); i++)
		{
			if (v[i - 1].get_title() > v[i].get_title()){
				sorted = false;
				break;
			}
		}

	} while (!sorted);

	return n;
}
